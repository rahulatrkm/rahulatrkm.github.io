# Portfolio

This is my Portfolio site.

## SVG

For the svg icon of Udacity, github, etc.
I found the icon here: <https://simpleicons.org/>
Then comes the udacity icon color which I found here: <https://color.adobe.com/udacity-color-theme-7942601/> which is "#06ADDB".

## Background Color

I kept the background color same as of Udacity website which is #2F4859.
I also chosen the svg background image from <https://www.svgbackgrounds.com/#protruding-squares>.
And learnt to apply parallax affect in css from <https://www.w3schools.com/howto/howto_css_parallax.asp>.
But, Later I found white background more beautiful. So, finally it is white.
